﻿using System;
namespace Tarea_2
{
	public class EmptyClass
	{
		public EmptyClass()
		{
	 
		}
	}
}

