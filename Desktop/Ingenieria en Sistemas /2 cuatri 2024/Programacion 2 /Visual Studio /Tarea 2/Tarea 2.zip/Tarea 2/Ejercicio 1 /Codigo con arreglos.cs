﻿using System;
namespace Tarea_2
{
	public class Codigo_con_arreglos
	{
		public Codigo_con_arreglos()
		{
		}
	}
}

